export interface Bank {
    branchId:any;
    branchName:any;
    ifsc:any;

    // accountNumber:any;
    // firstName:any;
    // lastName:any;
    // aadharNumber:any;
    // phoneNumber:any;
    // userName:any;
    // password:any;
    // balance:any;
    // aod:any;
    // status:any;


    
}
